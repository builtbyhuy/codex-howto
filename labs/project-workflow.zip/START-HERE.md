# A first project you can verify

Extract this entire archive to a new empty folder. Keep the included labs/project-workflow/ directory structure. Open the extraction root as your Codex practice project. Run the following commands from that root using an existing Node.js installation. No packages or service account are needed for these offline checks.

```text
node --test labs/project-workflow/workflow.test.cjs
node labs/project-workflow/verify-depth.cjs
```

Expected: Four integration tests pass when Git is installed. The depth demo checks nine distinct artifacts and counterexamples. Run verify-commit.cjs separately for actual commit coverage and HEAD evidence.

Read labs/project-workflow/README.md for the task, learner starter, reference solution, failure cases and limits. Reference checks and intentionally failing learner checks are different. The website does not activate any Codex configuration.
