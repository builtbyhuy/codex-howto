# A complete multicomponent workflow package

Extract this entire archive to a new empty folder. Keep the included labs/workflow-plugin/ directory structure. Open the extraction root as your Codex practice project. Run the following commands from that root using an existing Node.js installation. No packages or service account are needed for these offline checks.

```text
node --test labs/workflow-plugin/test.cjs labs/workflow-plugin/depth.test.cjs
node labs/workflow-plugin/demo.cjs
```

Expected: Twenty-four structural, behavioral, extension and subprocess checks pass. Two native metadata lifecycle versions were separately rehearsed on the documented author CLI; no authenticated model run or owner installation is implied.

Read labs/workflow-plugin/README.md for the task, learner starter, reference solution, failure cases and limits. Reference checks and intentionally failing learner checks are different. The website does not activate any Codex configuration.
