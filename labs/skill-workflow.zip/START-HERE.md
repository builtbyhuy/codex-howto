# A reusable review skill with a test boundary

Extract this entire archive to a new empty folder. Keep the included labs/skill-workflow/ directory structure. Open the extraction root as your Codex practice project. Run the following commands from that root using an existing Node.js installation. No packages or service account are needed for these offline checks.

```text
node --test labs/skill-workflow/review.test.cjs labs/skill-workflow/native-setup.test.cjs
node labs/skill-workflow/skill/scripts/review.cjs labs/skill-workflow/fixtures/broken
```

Expected: Eighteen package, helper and scratch-setup checks pass. Native skill selection and answer accuracy are separate client exercises, not inferred from helper output.

Read labs/skill-workflow/README.md for the task, learner starter, reference solution, failure cases and limits. Reference checks and intentionally failing learner checks are different. The website does not activate any Codex configuration.
