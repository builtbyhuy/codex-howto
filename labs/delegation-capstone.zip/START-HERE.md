# Two work packages, one integrated result

Extract this entire archive to a new empty folder. Keep the included labs/delegation-capstone/ directory structure. Open the extraction root as your Codex practice project. Run the following commands from that root using an existing Node.js installation. No packages or service account are needed for these offline checks.

```text
node --test labs/delegation-capstone/capstone.test.cjs labs/delegation-capstone/worktree.test.cjs
node labs/delegation-capstone/run.cjs solution
```

Expected: Nine baseline, reference and actual Git-worktree checks pass when Git is installed. The separate learner candidate starts red. Worktrees isolate files; they do not prove agents were spawned.

Read labs/delegation-capstone/README.md for the task, learner starter, reference solution, failure cases and limits. Reference checks and intentionally failing learner checks are different. The website does not activate any Codex configuration.
