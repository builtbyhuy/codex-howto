# Turn an event stream into a checked report

Extract this entire archive to a new empty folder. Keep the included labs/cli-pipeline/ directory structure. Open the extraction root as your Codex practice project. Run the following commands from that root using an existing Node.js installation. No packages or service account are needed for these offline checks.

```text
node --test labs/cli-pipeline/pipeline.test.cjs labs/cli-pipeline/extraction.test.cjs
node labs/cli-pipeline/verify-extraction.cjs
```

Expected: Thirty-two event, subprocess and final-extraction checks pass. The demo checks nine source, plan and failure cases without launching an authenticated Codex task.

Read labs/cli-pipeline/README.md for the task, learner starter, reference solution, failure cases and limits. Reference checks and intentionally failing learner checks are different. The website does not activate any Codex configuration.
