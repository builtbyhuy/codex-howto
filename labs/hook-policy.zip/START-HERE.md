# A preventive hook with an observable decision

Extract this entire archive to a new empty folder. Keep the included labs/hook-policy/ directory structure. Open the extraction root as your Codex practice project. Run the following commands from that root using an existing Node.js installation. No packages or service account are needed for these offline checks.

```text
node --test labs/hook-policy/test.cjs labs/hook-policy/depth.test.cjs
node labs/hook-policy/demo.cjs
```

Expected: Eighteen handler, artifact and workspace checks pass. The demo replays fictional events; native hook trust and interception remain a separate documented learner track.

Read labs/hook-policy/README.md for the task, learner starter, reference solution, failure cases and limits. Reference checks and intentionally failing learner checks are different. The website does not activate any Codex configuration.
