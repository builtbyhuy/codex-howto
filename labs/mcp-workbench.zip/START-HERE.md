# A local MCP server you can inspect

Extract this entire archive to a new empty folder. Keep the included labs/mcp-workbench/ directory structure. Open the extraction root as your Codex practice project. Run the following commands from that root using an existing Node.js installation. No packages or service account are needed for these offline checks.

```text
node --test labs/mcp-workbench/workbench.test.cjs labs/mcp-workbench/native-setup.test.cjs labs/mcp-workbench/app-server.test.cjs
node labs/mcp-workbench/demo.cjs
```

Expected: Twenty local protocol, setup and replacement-client checks pass, including stale-turn, malformed-tail and process-failure cases. Native no-turn MCP discovery was separately checked on the documented author CLI; model-selected invocation remains a learner exercise.

Read labs/mcp-workbench/README.md for the task, learner starter, reference solution, failure cases and limits. Reference checks and intentionally failing learner checks are different. The website does not activate any Codex configuration.
